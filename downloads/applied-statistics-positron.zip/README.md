# 307312 Applied Statistics — start here

Extract the whole ZIP. In Positron, choose File > Open Folder and open the extracted
folder containing _quarto.yml, data/ and .vscode/. Keep that folder structure intact.
Install R, Positron and Quarto, then run once in the R console:

```r
install.packages(c("knitr", "rmarkdown", "dplyr", "ggplot2", "readr", "tidyr", "zoo", "e1071", "MASS"))
```

Open the folders in this order:

1. **part-1-introduction-to-r/** — one combined Introduction to R notebook, from basic R to dplyr and ggplot2.
2. **part-2-descriptive-statistics/** — combined Descriptive Statistics notebook: explanations, diagrams and 20 runnable R examples, including line and dot plots.
3. **part-3-inferential-statistics/** — Inferential Statistics: the teaching slides and executable R examples together, from probability through regression.
4. **extended-cases/** — optional business applications, including Superstore.

Each course part has one notebook and a plain .R script containing its code.
Run the .R scripts from the top-level folder with data/ in place.
Each course part has one notebook. The same sources generate the website, PDFs
and the notebooks in this project. Parts 2 and 3 include their teaching material
and executable R examples together; there are no separate practical notebooks.

Keep data/, assets/ and support/ in place: they contain required data, images and a
shared R helper. There are 12 runnable notebooks. Supporting editable Part 2
diagrams are under support/. Website navigation pages and unused draft notebooks are excluded.

Keep the project root as the working directory. Open the top-level course folder in Positron and select an R interpreter.
The supplied workspace runs Quarto cells in the R Console from the course root.
Run cells in order; use Preview to render the notebook with its outputs.
If a CSV cannot be found, use getwd() in the R Console to check that the working
folder contains data/. Reopen the top-level course folder if needed.
Run `quarto render` from the project root to render all material. No Python is required.
PDF/download links use the website.

Website: https://msfasha.github.io/307312-Applied-Statistics/
