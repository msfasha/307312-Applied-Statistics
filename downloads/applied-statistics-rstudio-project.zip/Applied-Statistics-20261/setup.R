# c() combines package names into a character vector for the installation step.
# install.packages() downloads these packages from the specified CRAN repository; run this once online.
packages <- c("knitr", "rmarkdown", "ggplot2", "dplyr", "tidyr", "readr", "stringr")
install.packages(packages, repos = "https://cloud.r-project.org")
