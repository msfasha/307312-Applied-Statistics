# Applied Statistics: student RStudio project

1. Extract the entire ZIP to a writable folder.
2. Install R (4.1 or newer), RStudio Desktop, and Quarto if they are not installed.
3. Open `20261.Rproj` in RStudio. Keep it open while working with lesson files.
4. Open `setup.R` and run it once to install the required R packages. This needs internet access.
5. Open `index.qmd`, or a numbered lesson under `modules/`. Use Render to create its HTML page.
6. Save your own exercises and reports in a new folder such as `my-work/`.

HTML rendering does not require Python or LaTeX. Run individual R chunks while
practicing, and click Render when you want an HTML page. Rebuilding the whole
website is optional: run `quarto render` in RStudio's Terminal.

The included CSVs are ready for lesson use. Local instructor textbook PDFs, publisher
workbooks, original measurement workbooks, instructor answers, and instructor-only
verification scripts are not required and are not included. Provenance notes identify
those original sources; paths to them describe the instructor's local collection.

Reading the website or supplied PDFs does not require R or RStudio. Individual PDF
rendering additionally needs the LaTeX/fonts documented by your instructor; use the
separate ready-made PDF download if you only want to read or print.

Course website: https://msfasha.github.io/307312-Applied-Statistics/
Student downloads: https://msfasha.github.io/307312-Applied-Statistics/resources/downloads.html

Keep attribution and source notices with redistributed material. Third-party teaching
data and textbook excerpts retain their original rights and are not relicensed by this project.
