# 307312 Applied Statistics - student project

1. Install R, RStudio, and Quarto.
2. Extract this whole ZIP to a folder and open Applied-Statistics.Rproj.
3. Run this once in the R console:
   install.packages(c("knitr", "rmarkdown", "dplyr", "ggplot2", "readr", "tidyr", "zoo"))
4. Open lessons/01-introduction-to-r.qmd, followed by r-02-basic-concepts.qmd, r-03-dplyr.qmd and r-04-ggplot2.qmd, then Parts 2 and 3. Run code chunks in order.
5. After the Part 2 slides, open practicals/descriptive-statistics-r-practical.qmd.
   Run its 18 worked examples in order; these use the original student teaching CSV.
6. Choose Render to view a notebook. Run `quarto render practicals` for practicals.
7. Run `quarto render` to build the lesson website.
8. Choose optional activities in extended-cases/. Superstore is grouped under
   extended-cases/superstore/; start with its index.qmd. Each case lists prerequisites.
   Run `quarto render extended-cases/case-02-oxford-cereal.qmd` for one case.

Parts 2 and 3 preserve the original slide-based lessons and Excel instructions.
Part 2 R examples are collected in the separate descriptive R practical; Part 3
keeps its labeled R examples. Their original teaching CSVs and diagrams are included.
The Superstore extended case uses the US 2023–2025 extract.
The extended cases add historical ninth-edition business cases and summary inputs.
All sixteen notebooks are included; choose the extended cases assigned by your instructor.
See data/business/README.md for provenance, units and limitations.
The six numbered extended cases provide separate business applications of course concepts.
Python 3 is needed for the small HTML post-render step.
PDF and ZIP download links point to the published website; local rendering creates HTML.
Keep the complete folder structure. Open Applied-Statistics.Rproj and keep the
working directory at the project root. In RStudio, set Tools > Global Options >
R Markdown > Evaluate chunks in directory to Project. Read CSVs using their
data/ paths. All teaching data is CSV.
Website: https://msfasha.github.io/307312-Applied-Statistics/
