# 307312 Applied Statistics - student project

1. Install R, RStudio, and Quarto.
2. Extract this whole ZIP to a folder and open Applied-Statistics.Rproj.
3. Run this once in the R console:
   install.packages(c("knitr", "rmarkdown", "dplyr", "ggplot2"))
4. Open 01-introduction-to-r.qmd, then Parts 2 and 3. Run code chunks in order.
5. Choose Render to view a lesson. Run `quarto render` to build the website.

MASS is a recommended R package used in Part 3; install it if absent.
Python 3 is needed for the small HTML post-render step.
PDF and ZIP download links point to the published website; local rendering creates HTML.
Keep assets/, content/, and data/ beside the notebooks. All teaching data is CSV.
Website: https://msfasha.github.io/307312-Applied-Statistics/
