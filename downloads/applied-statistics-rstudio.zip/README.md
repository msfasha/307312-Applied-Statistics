# 307312 Applied Statistics — start here

Extract the whole ZIP and open Applied-Statistics.Rproj in RStudio.
Install R, RStudio and Quarto, then run once in the R console:

```r
install.packages(c("knitr", "rmarkdown", "dplyr", "ggplot2", "readr", "tidyr", "zoo", "e1071"))
```

Open the folders in this order:

1. **part-1-introduction-to-r/** — four R notebooks, in order: 01, r-02, r-03, r-04.
2. **part-2-descriptive-statistics/** — runnable descriptive R practical (18 examples).
3. **part-3-inferential-statistics/** — developing inference R practical (probability available; estimation, testing and regression forthcoming).
4. **extended-cases/** — optional business applications, including Superstore.

Teaching slides and the revised probability lesson are available on the course website
and as PDFs. Links to those lessons open the website; their sources are not in this ZIP.

Keep data/, assets/ and support/ in place: they contain required data, images and a
shared R helper. There are 15 runnable notebooks. Website navigation pages, slide-lesson
sources, obsolete redirects and unpublished review notebooks are excluded.

Keep the project root as the working directory. In RStudio, set Tools > Global Options >
R Markdown > Evaluate chunks in directory to Project. Run chunks in order, or use Render.
Run `quarto render` from the project root to render all material. No Python is required.
PDF/download links use the website.

Website: https://msfasha.github.io/307312-Applied-Statistics/
